package studentCoursesBackup.myTree;

import studentCoursesBackup.other.PassParameter;

public interface ObserverI {

	public void update(PassParameter P);
}
